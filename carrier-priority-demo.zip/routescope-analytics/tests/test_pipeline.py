import tempfile
import unittest
from pathlib import Path
from pipeline import run

class CoverageTests(unittest.TestCase):
    def test_minimal_prefix_and_quarantine(self):
        with tempfile.TemporaryDirectory() as directory:
            rows, rejected = run(output=Path(directory))
            self.assertEqual(len(rejected), 2)
            for route in { (r['origin'], r['destination']) for r in rows }:
                carriers = [r for r in rows if (r['origin'], r['destination']) == route]
                selected = [r for r in carriers if r['selected']]
                self.assertGreaterEqual(sum(r['market_share'] for r in selected), 0.8 - 1e-12)
                self.assertLess(sum(r['market_share'] for r in selected[:-1]), 0.8 - 1e-12)
            atl = [r['airline'] for r in rows if r['origin'] == 'ATL' and r['destination'] == 'JFK' and r['selected']]
            self.assertEqual(atl, ['DL', 'AA'])

    def test_full_coverage_and_invalid_target(self):
        with tempfile.TemporaryDirectory() as directory:
            rows, _ = run(output=Path(directory), target=1)
            self.assertTrue(all(r['selected'] for r in rows))
        for target in (0, -0.1, 1.1):
            with self.assertRaises(ValueError):
                run(target=target)

if __name__ == '__main__':
    unittest.main()
