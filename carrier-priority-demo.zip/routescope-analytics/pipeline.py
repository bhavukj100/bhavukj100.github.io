"""RouteScope: reproducible carrier selection demo. Synthetic data, no employer source code."""
import argparse
import csv
import json
import sqlite3
from pathlib import Path

ROOT = Path(__file__).parent

def run(source=ROOT / 'data/flights.csv', output=ROOT / 'output', target=0.8):
    if not 0 < target <= 1:
        raise ValueError('Coverage target must be greater than zero and at most one')
    db = sqlite3.connect(':memory:')
    db.execute('CREATE TABLE flights (origin TEXT, destination TEXT, airline TEXT, flights INTEGER, fare REAL)')
    accepted, rejected = [], []
    with open(source, newline='') as handle:
        for row in csv.DictReader(handle):
            try:
                origin, dest, airline = (row[k].strip().upper() for k in ('origin', 'destination', 'airline'))
                flights, fare = int(row['flights']), float(row['fare'])
                if len(origin) != 3 or len(dest) != 3 or not airline or origin == dest or flights <= 0 or not 0 < fare < float('inf'):
                    raise ValueError('Invalid route, volume, or fare')
                accepted.append((origin, dest, airline, flights, fare))
            except (ValueError, KeyError, TypeError) as exc:
                rejected.append(dict(row, error=str(exc)))
    db.executemany('INSERT INTO flights VALUES (?,?,?,?,?)', accepted)
    result = db.execute((ROOT / 'sql/carrier_priority.sql').read_text(), {'target': target})
    fields = [column[0] for column in result.description]
    rows = [dict(zip(fields, row)) for row in result.fetchall()]
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    with open(output / 'carrier_priority.csv', 'w', newline='') as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
    (output / 'quality_report.json').write_text(json.dumps({'accepted_rows': len(accepted), 'rejected_rows': len(rejected), 'target': target, 'rejections': rejected}, indent=2))
    db.close()
    return rows, rejected

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--target', type=float, default=0.8)
    parser.add_argument('--input', type=Path, default=ROOT / 'data/flights.csv')
    parser.add_argument('--output', type=Path, default=ROOT / 'output')
    args = parser.parse_args()
    rows, rejected = run(args.input, args.output, args.target)
    print(f'Wrote {len(rows)} carrier rows; rejected {len(rejected)} invalid input rows.')
