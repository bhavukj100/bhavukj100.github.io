# RouteScope Analytics

A compact, reproducible travel data engineering portfolio demo prepared for Bhavuk Jain with AI assistance. This is a new implementation using synthetic data, built around a generic airline market-coverage problem. It contains no employer code or proprietary data and is not a fork of another repository.

## Business problem
Choose the smallest ranked prefix of airlines that covers a configurable fraction of flight volume for each origin-destination market. This can inform which airline integrations to prioritize. Actual API latency or cost improvements have not been measured in this demo.

## Run in under a minute
Requires Python 3.10+ with SQLite window-function support. No packages or cloud account required.

```bash
python pipeline.py
python -m unittest discover -s tests -v
python pipeline.py --target 0.9
```

Outputs: `output/carrier_priority.csv` and `output/quality_report.json`.

## Architecture
CSV ingestion feeds validated records into SQLite. SQL aggregates flight volume, calculates market share, ranks carriers, and chooses a minimal prefix. The pipeline exports analytics-ready CSV and a quality report. Invalid rows are quarantined in the report.

## Example
The synthetic ATL-JFK market has DL 50%, AA 30%, UA 15%, and B6 5%. At 80% coverage the output selects DL and AA. The boundary carrier is included if needed to cross the target. Ties use airline code for deterministic ordering.

## Engineering decisions
- SQL window functions make route rankings explicit and reviewable.
- The threshold uses cumulative share before the current carrier so the boundary carrier is included.
- SQLite and standard-library Python keep setup fast and reproducible.
- The input is assumed to contain additive aggregate observations. Duplicate ingestion is not deduplicated. Production ingestion needs stable event identifiers and a watermark.
- Outputs overwrite the same files on rerun. This is a small local demo, not a cloud deployment.

## Validation
Tests check minimal-prefix coverage, exact 80% boundary behavior, invalid-row rejection, 100% coverage, and invalid targets. CI runs the tests and the example pipeline.

## Next extensions
Port transformations to PySpark, write Parquet or Delta, add freshness validation and event-id deduplication, and orchestrate with Airflow. These are future extensions, not implemented capabilities.

## Interview walkthrough
Explain the business objective, input grain, quality rules, window frames, boundary handling, deterministic ties, and batch-versus-streaming tradeoff. Run the pipeline and show both output files. Review the code before listing this as a project on your resume.

## Resume wording after you review and run it
Developed a travel-data portfolio pipeline using Python and SQL to validate flight records, rank airlines by route-level market share, and export configurable carrier-priority recommendations with automated coverage checks.

## Publish to GitHub
Create an empty public repository named `routescope-analytics` on GitHub. Extract this package and upload all project files, including `.github/workflows/tests.yml`. For Git CLI:

```bash
git init
git add .
git commit -m "Add carrier prioritization portfolio demo"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/routescope-analytics.git
git push -u origin main
```
