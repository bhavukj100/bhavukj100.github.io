WITH volumes AS (
  SELECT origin, destination, airline, SUM(flights) AS flight_count,
         MIN(fare) AS minimum_fare
  FROM flights GROUP BY origin, destination, airline
), shares AS (
  SELECT *, 1.0 * flight_count / SUM(flight_count)
    OVER (PARTITION BY origin, destination) AS market_share
  FROM volumes
), ranked AS (
  SELECT *, ROW_NUMBER() OVER (
      PARTITION BY origin, destination ORDER BY flight_count DESC, airline
    ) AS priority_rank,
    SUM(market_share) OVER (
      PARTITION BY origin, destination ORDER BY flight_count DESC, airline
      ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS cumulative_share
  FROM shares
)
SELECT origin, destination, airline, flight_count, minimum_fare,
       market_share, priority_rank, cumulative_share,
       CASE WHEN cumulative_share - market_share < :target - 1e-12
            THEN 1 ELSE 0 END AS selected
FROM ranked ORDER BY origin, destination, priority_rank;
